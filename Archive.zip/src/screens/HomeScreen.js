import React, { useState, useRef, useEffect } from 'react';
import { View, SafeAreaView, Text, Dimensions, FlatList } from 'react-native';
import { styles } from '../constants/styles'
import { colors } from '../constants'
import { Icon, Input, Button } from 'react-native-elements';
import { IconButton } from '../components/IconButton'
import { PointerIcon } from '../components/PointerIcon'
import { ListItem } from 'react-native-elements/dist/list/ListItem';

const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;


const HomeScreen = () => {

    const [activeIcon, setActiveIcon] = useState(1)
    const [currentIndex, setIndex] = useState(0)

    useEffect(() => {

    }, [currentIndex])

    const cards = [
        {
            id: 1,
            title: 'card 1',
            color: colors.ORANGE
        },
        {
            id: 2,
            title: 'card 2',
            color: 'green'
        },
        {
            id: 3,
            title: 'card 3',
            color: colors.WHITE
        }
    ]

    const handleViewableItemsChanged = useRef(({ viewableItems, changed }) => {
        if (viewableItems[0]) {
            console.log('viewableItems', viewableItems[0].index);
            console.log('changed', changed);
            setIndex(viewableItems[0].index)
        }
    }, []);

    const viewabilityConfig = {
        itemVisiblePercentThreshold: 70
    }


    const renderCard = ({ item, index }) => {
        let activeStyle
        return (
            <View style={{ height: 200, width: 260,}}>
                <View style={{ width: 250, height: currentIndex == index ? 200 : 100, backgroundColor: item.color, margin: 10, marginLeft: index == 0 ? 50 : 0, }}>
                    <Text>{item.title}</Text>
                </View>
            </View>
        )
    }

    return (
        <SafeAreaView style={[styles.container]}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 10 }}>
                <Input
                    placeholder='Cüzdan Ara…'
                    leftIcon={{ type: 'font-awesome-5', name: 'search', color: colors.PURPLE, size: 11 }}
                    placeholderTextColor={colors.GREY}
                    inputStyle={{ fontSize: 11 }}
                    secureTextEntry={true}
                    inputContainerStyle={{ borderBottomWidth: 0 }}
                    containerStyle={{ width: windowWidth * 0.5, alignItems: 'center', height: 45 }}
                />
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Text style={[styles.textStyle, { fontSize: 11, fontWeight: 'bold' }]}>TÜM CÜZDANLAR</Text>
                    <Icon
                        type="font-awesome-5"
                        name='filter'
                        size={15}
                        color={colors.PURPLE}
                        containerStyle={{ marginLeft: 5 }}
                    />
                </View>
            </View>
            <View style={{ height: 190, backgroundColor: colors.PURPLE }}>
                <FlatList
                    data={cards}
                    renderItem={renderCard}
                    keyExtractor={item => item.id}
                    horizontal
                    onViewableItemsChanged={handleViewableItemsChanged.current}
                    viewabilityConfig={viewabilityConfig}
                    pagingEnabled={true}
                    snapToAlignment={'center'}
                    snapToInterval={200}
                    decelerationRate="fast"
                    contentContainerStyle={{ flexGrow: 1, justifyContent: 'space-between', borderWidth: 2, borderColor: 'red', alignItems: 'center' }}
                    style={{paddingEnd:50}}
                />
            </View>
            <View style={{ alignItems: 'center' }}>
                <IconButton
                    title='Kampanyalar'
                    iconName='gift'
                    iconSize={25}
                    iconColor={colors.ORANGE}
                    buttonColor={colors.WHITE}
                    borderWidth={2}
                    titleColor={colors.PURPLE}
                />
                <IconButton
                    title='Cüzdan Ekle'
                    iconName='wallet'
                    iconSize={25}
                    iconColor={colors.WHITE}
                    buttonColor={colors.PURPLE}
                    borderWidth={0}
                    titleColor={colors.WHITE}
                />
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-evenly' }}>
                <PointerIcon
                    iconName='wallet'
                    active={activeIcon == 1 ? true : false}
                    onPress={() => setActiveIcon(1)}
                />
                <PointerIcon
                    iconName='credit-card'
                    active={activeIcon == 2 ? true : false}
                    onPress={() => setActiveIcon(2)}

                />
                <PointerIcon
                    iconName='cloud-upload-alt'
                    active={activeIcon == 3 ? true : false}
                    onPress={() => setActiveIcon(3)}
                />
                <PointerIcon
                    iconName='history'
                    active={activeIcon == 4 ? true : false}
                    onPress={() => setActiveIcon(4)}
                />
            </View>

        </SafeAreaView>
    );
}

export default HomeScreen;