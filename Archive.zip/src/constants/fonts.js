export default {
    DEFAUTL: 'Roboto-Regular',
    
}