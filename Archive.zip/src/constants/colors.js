export default {
    BLACK: '#000',
    WHITE: '#fff',
    GREY: '#49495C',
    PURPLE:'#2C2C58',
    ICON: '#8C8CA4',
    BORDER: '#F7F7F7',
    ORANGE: '#FF7F00'
}